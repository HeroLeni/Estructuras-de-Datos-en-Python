numeros = (1, 2, 3, 4, 5, 6)

print("Tupla original:", numeros)
print("MENÚ:")
print("1. agregar un valor")
print("2. cambiar un valor")
print("3. eliminar un valor")
print("4. mostrar todos los valores")
print("5. Salir")

opcion = input("Elige (1-4): ")

if opcion == "1":
    nuevo = int(input("ingresa el numero que desees agregar: "))
    nueva_tupla = numeros + (nuevo,)
    print("Quedaría así:", nueva_tupla)

elif opcion == "2":
    print("estos son los numeros: ", numeros)
    pos = int(input("elige la posicion a cambiar: (0-5): "))
    nuevo = int(input("el nuevo valor: "))

    if 0 <= pos < len(numeros):
            lista = list(numeros)
            lista[pos] = nuevo
            nueva_tupla = tuple(lista)
            print("el resultado es:", nueva_tupla)
    else:
            print("opcion invalida")

elif opcion == "3":
        print("Tupla:", numeros)
        pos = int(input("eliminar el numero (0-5): "))
        
        if 0 <= pos < len(numeros):
            lista = list(numeros)
            lista.pop(pos)
            nueva_tupla = tuple(lista)
            print("Se elimino con exito, quedo asi:", nueva_tupla)
        else:
            print("opcion invalida")

elif opcion == "4":
        print("Valores con posiciones:")
        for i in range(len(numeros)):
            print(f"Posición {i}: {numeros[i]}")


print("resumen final")

mayor = numeros[0]
for num in numeros:
    if num > mayor:
        mayor = num

menor = numeros[0]
for num in numeros:
    if num < menor:
        menor = num

suma = 0
for num in numeros:
    suma = suma + num

pos_mayor = 0
for i in range(len(numeros)):
    if numeros[i] == mayor:
        pos_mayor = i

print(f"Valor mayor: {mayor}")
print(f"Valor menor: {menor}")
print(f"Suma total: {suma}")
print(f"Posición del mayor: {pos_mayor}")