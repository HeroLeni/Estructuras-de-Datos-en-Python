print("Registro de asistencia: ")

nombres = ['fares', 'Mizushima', 'Jeremy', 'Charaneitor', 'Julian', 'Ger']
registros = 0
print("1. Registro de estudiante")
print("2. mostreo de nombres")
print("3. Cambiar nombre de estudiante")
print("4. Salir")
menu = input("Ingresa la opcion que desees hacer (1-5): ")
if menu == "1":
    nuevo = input("Ingresa el nombre que deseas agregar: ")

    if nuevo in nombres:
        print(" Ese nombre ya existe en la lista.")
    else:
        nombres.append(nuevo)
        print(" Nombre agregado correctamente.")
elif menu == "2":
    print("Lista de nombres:")
    for i, nombre in enumerate(nombres):
        print(f"{i}. {nombre}")
elif menu == "3":
    antiguo_nombre = input("ingresa el nombre antiguo: ")
    if antiguo_nombre not in nombres:
        print("error, ")

elif menu == 4:
    print("Lista actual:")
    for i, nombre in enumerate(nombres):
        print(f"{i}. {nombre}")

    pos = int(input("Ingresa el nombre a eliminar: "))

    if pos < 0 or pos >= len(nombres):
        print(" incorrecto.")
    else:
        eliminado = nombres.pop(pos)
        print(f" Nombre '{eliminado}' eliminado correctamente.")

else:
    print("Opción no válida.")

print("Lista final:", nombres)