inventario = {
    "PS5": 2800,
    "Xbox Series X": 2700,
    "Switch 2": 1500,
}

print("Inventario básico - Opciones:")
print("1. Agregar un producto")
print("2. Consultar precio de un producto")
print("3. Modificar precio de un producto")
print("4. Eliminar un producto")

opcion = input("Selecciona una opción (1-4): ")

if opcion == "1":
    producto = input("Nombre del producto a agregar: ")
    if producto in inventario:
        print("Error: El producto ya está en el inventario.")
    else:
        precio = float(input("Precio del producto: "))
        inventario[producto] = precio
        print(f"Producto {producto} agregado con precio {precio}")

elif opcion == "2":
    producto = input("Nombre del producto a consultar: ")
    if producto in inventario:
        print(f"El precio de {producto} es {inventario[producto]}")
    else:
        print("Producto no encontrado.")

elif opcion == "3":
    producto = input("Nombre del producto a modificar: ")
    if producto in inventario:
        nuevo_precio = float(input("Nuevo precio: "))
        inventario[producto] = nuevo_precio
        print(f"Precio de {producto} actualizado a {nuevo_precio}")
    else:
        print("Producto no encontrado.")

elif opcion == "4":
    producto = input("Nombre del producto a eliminar: ")
    if producto in inventario:
        del inventario[producto]
        print(f"Producto {producto} eliminado del inventario.")
    else:
        print("Producto no encontrado.")

else:
    print("Opción no válida.")

total_productos = len(inventario)
if total_productos > 0:
    promedio_precios = sum(inventario.values()) / total_productos
else:
    promedio_precios = 0

print(f"Cantidad total de productos: {total_productos}")
print(f"Precio promedio de los productos: {promedio_precios:.2f}")
print("Inventario actual:", inventario)
